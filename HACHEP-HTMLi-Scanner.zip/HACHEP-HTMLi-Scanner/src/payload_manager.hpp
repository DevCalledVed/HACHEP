#ifndef PAYLOAD_MANAGER_HPP
#define PAYLOAD_MANAGER_HPP

#include <vector>
#include <string>

class PayloadManager {
public:
    PayloadManager();
    std::vector<std::string> getPayloads();

private:
    std::vector<std::string> payloads;
    void initializePayloads();
};

#endif
