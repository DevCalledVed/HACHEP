#ifndef UTILS_HPP
#define UTILS_HPP

#include <string>

class Utils {
public:
    static bool isValidUrl(const std::string& url);
    static std::string sendRequest(const std::string& url, const std::string& payload);
    static size_t WriteCallback(void* contents, size_t size, size_t nmemb, void* userp);
};

#endif
