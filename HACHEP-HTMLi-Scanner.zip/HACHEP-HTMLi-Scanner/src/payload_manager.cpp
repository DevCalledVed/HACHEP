#include "payload_manager.hpp"

PayloadManager::PayloadManager() {
    initializePayloads();
}

void PayloadManager::initializePayloads() {
    // Safe test payloads that won't harm the target system
    payloads = {
        "<test>harmless</test>",
        "<!--test-->",
        "<div id=\"scanner-test\"></div>",
        "<span class=\"scanner-test\">test</span>",
        "<script>/* test */</script>",
        "<img src=\"x\" onerror=\"console.log('test')\">"
    };
}

std::vector<std::string> PayloadManager::getPayloads() {
    return payloads;
}
