#include "utils.hpp"
#include <curl/curl.h>
#include <regex>
#include <stdexcept>

bool Utils::isValidUrl(const std::string& url) {
    std::regex urlRegex(
        R"(https?:\/\/(www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_\+.~#?&//=]*))"
    );
    return std::regex_match(url, urlRegex);
}

size_t Utils::WriteCallback(void* contents, size_t size, size_t nmemb, void* userp) {
    ((std::string*)userp)->append((char*)contents, size * nmemb);
    return size * nmemb;
}

std::string Utils::sendRequest(const std::string& url, const std::string& payload) {
    CURL* curl = curl_easy_init();
    std::string response;

    if (!curl) {
        throw std::runtime_error("Failed to initialize CURL");
    }

    std::string fullUrl = url;
    if (!payload.empty()) {
        char* escaped_payload = curl_easy_escape(curl, payload.c_str(), payload.length());
        if (escaped_payload) {
            fullUrl += std::string("?test=") + std::string(escaped_payload);
            curl_free(escaped_payload);
        }
    }

    curl_easy_setopt(curl, CURLOPT_URL, fullUrl.c_str());
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response);
    curl_easy_setopt(curl, CURLOPT_USERAGENT, "VulnerabilityScanner/1.0");
    curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT, 10L);

    CURLcode res = curl_easy_perform(curl);

    if (res != CURLE_OK) {
        curl_easy_cleanup(curl);
        throw std::runtime_error(curl_easy_strerror(res));
    }

    curl_easy_cleanup(curl);
    return response;
}