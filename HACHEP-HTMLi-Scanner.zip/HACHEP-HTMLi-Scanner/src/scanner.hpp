#ifndef SCANNER_HPP
#define SCANNER_HPP

#include <string>
#include <vector>
#include <memory>
#include "crawler.hpp"
#include "payload_manager.hpp"

class Scanner {
public:
    explicit Scanner(const std::string& baseUrl);
    void startScan();

private:
    std::string baseUrl;
    std::unique_ptr<Crawler> crawler;
    std::unique_ptr<PayloadManager> payloadManager;
    
    void testEndpoint(const std::string& url);
    void analyzeResponse(const std::string& url, const std::string& payload, const std::string& response);
    void reportVulnerability(const std::string& url, const std::string& payload, const std::string& type);
    bool isReflectedInjection(const std::string& payload, const std::string& response);
    bool isStoredInjection(const std::string& payload, const std::string& response);
};

#endif
