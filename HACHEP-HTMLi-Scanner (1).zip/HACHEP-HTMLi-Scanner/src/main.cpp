#include <iostream>
#include <string>
#include "scanner.hpp"
#include "utils.hpp"

using namespace std;

int main() {
    cout << R"(
        ██╗  ██╗  █████╗   ██████╗██╗  ██╗███████╗██████╗ 
        ██║  ██║ ██╔══██╗ ██╔════╝██║  ██║██╔════╝██╔══██╗
        ███████║ ███████║ ██║     ███████║█████╗  ██████╔╝
        ██╔══██║ ██╔══██║ ██║     ██╔══██║██╔══╝  ██╔═══╝ 
        ██║  ██║ ██║  ██║ ╚██████╗██║  ██║███████╗██║     
        ╚═╝  ╚═╝ ╚═╝  ╚═╝  ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝     
                                                         )" << endl;
    cout << "HTML Injection Vulnerability Scanner\n";
    cout << "====================================\n";
    cout << "Please enter the URL to scan: ";
    
    string url;
    getline(cin, url);

    if (!Utils::isValidUrl(url)) {
        cerr << "Error: Invalid URL format\n";
        return 1;
    }

    Scanner scanner(url);
    
    try {
        cout << "Starting scan...\n";
        scanner.startScan();
    } catch (const exception& e) {
        cerr << "Error during scan: " << e.what() << "\n";
        return 1;
    }

    return 0;
}
