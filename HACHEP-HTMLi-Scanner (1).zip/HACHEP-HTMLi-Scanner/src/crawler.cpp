#include "crawler.hpp"
#include "utils.hpp"
#include <regex>
#include <iostream>
#include <queue>

Crawler::Crawler(const std::string& baseUrl) : baseUrl(baseUrl) {}

std::vector<std::string> Crawler::crawl() {
    std::vector<std::string> endpoints;
    std::queue<std::string> urlQueue;

    if (!checkRobotsTxt(baseUrl)) {
        std::cout << "Crawling not allowed by robots.txt\n";
        return endpoints;
    }

    urlQueue.push(baseUrl);

    while (!urlQueue.empty() && visitedUrls.size() < 100) { // Limit crawling depth
        std::string currentUrl = urlQueue.front();
        urlQueue.pop();

        if (visitedUrls.find(currentUrl) != visitedUrls.end()) {
            continue;
        }

        visitedUrls.insert(currentUrl);

        try {
            std::string response = Utils::sendRequest(currentUrl, "");
            auto links = extractLinks(response);

            for (const auto& link : links) {
                if (shouldCrawl(link)) {
                    urlQueue.push(link);
                }
            }

            endpoints.push_back(currentUrl);

        } catch (const std::exception& e) {
            std::cerr << "Error crawling " << currentUrl << ": " << e.what() << "\n";
        }
    }

    return endpoints;
}

bool Crawler::shouldCrawl(const std::string& url) {
    // Check if URL is within the same domain
    return url.find(baseUrl) == 0;
}

std::vector<std::string> Crawler::extractLinks(const std::string& html) {
    std::vector<std::string> links;
    std::regex linkRegex("href=[\"']([^\"']+)[\"']");

    auto wordsBegin = std::sregex_iterator(html.begin(), html.end(), linkRegex);
    auto wordsEnd = std::sregex_iterator();

    for (std::sregex_iterator i = wordsBegin; i != wordsEnd; ++i) {
        std::string link = (*i)[1];
        if (link.substr(0, 4) == "http") {
            links.push_back(link);
        } else if (link.substr(0, 1) == "/") {
            links.push_back(baseUrl + link);
        }
    }

    return links;
}

bool Crawler::checkRobotsTxt(const std::string& url) {
    std::string robotsUrl = url + "/robots.txt";
    try {
        std::string response = Utils::sendRequest(robotsUrl, "");
        // Basic check - if "Disallow: /" is present, don't crawl that link
        return response.find("Disallow: /") == std::string::npos;
    } catch (...) {
        return true; // If robots.txt doesn't exist, assume crawling is allowed
    }
}