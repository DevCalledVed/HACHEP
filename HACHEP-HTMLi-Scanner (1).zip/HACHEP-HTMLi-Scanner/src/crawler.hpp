#ifndef CRAWLER_HPP
#define CRAWLER_HPP

#include <string>
#include <vector>
#include <set>

class Crawler {
public:
    explicit Crawler(const std::string& baseUrl);
    std::vector<std::string> crawl();

private:
    std::string baseUrl;
    std::set<std::string> visitedUrls;
    bool shouldCrawl(const std::string& url);
    std::vector<std::string> extractLinks(const std::string& html);
    bool checkRobotsTxt(const std::string& url);
};

#endif
