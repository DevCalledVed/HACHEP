#include "scanner.hpp"
#include "utils.hpp"
#include <iostream>
#include <chrono>
#include <thread>
#include <curl/curl.h>

Scanner::Scanner(const std::string& baseUrl) : baseUrl(baseUrl) {
    crawler = std::make_unique<Crawler>(baseUrl);
    payloadManager = std::make_unique<PayloadManager>();
}

void Scanner::startScan() {
    std::cout << "Initializing scan of: " << baseUrl << "\n";
    
    // First, crawl the website to discover endpoints
    auto endpoints = crawler->crawl();
    
    std::cout << "Discovered " << endpoints.size() << " endpoint/s \n";
    
    // Test each endpoint
    for (const auto& endpoint : endpoints) {
        std::cout << "Testing endpoint: " << endpoint << "\n";
        testEndpoint(endpoint);
        // Implement rate limiting
        std::this_thread::sleep_for(std::chrono::milliseconds(500));
    }
    
    std::cout << "Scan completed\n";
}

void Scanner::testEndpoint(const std::string& url) {
    auto payloads = payloadManager->getPayloads();
    
    for (const auto& payload : payloads) {
        std::string response = Utils::sendRequest(url, payload);
        analyzeResponse(url, payload, response);
    }
}

void Scanner::analyzeResponse(const std::string& url, const std::string& payload, const std::string& response) {
    if (isReflectedInjection(payload, response)) {
        reportVulnerability(url, payload, "Reflected HTML Injection");
    }
    if (isStoredInjection(payload, response)) {
        reportVulnerability(url, payload, "Stored HTML Injection");
    }
    if (isDOMBasedInjection(payload, response)) {
        reportVulnerability(url, payload, "DOM-based HTML Injection");
    }
}

bool Scanner::isReflectedInjection(const std::string& payload, const std::string& response) {
    return response.find(payload) != std::string::npos;
}

bool Scanner::isStoredInjection(const std::string& payload, const std::string& response) {
    // First request: Send the payload
    std::string initialResponse = Utils::sendRequest(baseUrl, payload);
    
    // Wait briefly to allow for storage
    std::this_thread::sleep_for(std::chrono::seconds(2));
    
    // Second request: Check if payload persists without sending it again
    std::string checkResponse = Utils::sendRequest(baseUrl, "");
    
    // If payload is found in the second response, it might be stored
    return checkResponse.find(payload) != std::string::npos;
}

bool Scanner::isDOMBasedInjection(const std::string& payload, const std::string& response) {
    // Check for common DOM manipulation patterns
    std::vector<std::string> domPatterns = {
        "document.write",
        "innerHTML",
        "outerHTML",
        "insertAdjacentHTML",
        "eval(",
        "setTimeout",
        "setInterval"
    };
    
    // Check if response contains both the payload and DOM manipulation code
    for (const auto& pattern : domPatterns) {
        if (response.find(pattern) != std::string::npos && 
            response.find(payload) != std::string::npos) {
            return true;
        }
    }
    
    return false;
}

void Scanner::reportVulnerability(const std::string& url, const std::string& payload, const std::string& type) {
    std::cout << "\n[VULNERABILITY FOUND]\n";
    std::cout << "Type: " << type << "\n";
    std::cout << "URL: " << url << "\n";
    std::cout << "Payload: " << payload << "\n";
    std::cout << "-------------------\n";
}
